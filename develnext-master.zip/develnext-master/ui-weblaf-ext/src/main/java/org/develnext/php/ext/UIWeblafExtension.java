package org.develnext.php.ext;

import org.develnext.jphp.swing.SwingExtension;
import php.runtime.env.CompileScope;
import php.runtime.env.Environment;

public class UIWeblafExtension extends SwingExtension {
    @Override
    public void onLoad(Environment env) {
    }

    @Override
    public void onRegister(CompileScope scope) {

    }
}
