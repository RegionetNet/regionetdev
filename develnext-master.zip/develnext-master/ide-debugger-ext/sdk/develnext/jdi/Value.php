<?php
namespace develnext\jdi;

/**
 * Use VirtualMachine.new*Value method to instance a value
 *
 * Class Value
 * @package develnext\jdi
 */
class Value {

    /**
     * @return array [name, signature]
     */
    public function getType() { return []; }
}
