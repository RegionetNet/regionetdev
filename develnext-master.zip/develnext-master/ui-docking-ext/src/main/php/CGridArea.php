<?php
namespace php\swing\docking;

use php\swing\UIContainer;

/**
 * Class CGridArea
 * @package php\swing\docking
 */
class CGridArea extends CDockable {

    /**
     *
     */
    private function __construct() { }

    /**
     * @return UIContainer
     */
    public function getComponent() { }
}