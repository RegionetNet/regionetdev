﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" <?php if(is_right_to_left($lang)) echo "dir='rtl'"; ?>>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="Description" content="Internet CheckOut" />
	<meta name="Keywords" content="" />
  <title>InternetCheckout</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v2.11.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="http://bombnet.ru/assets/images/6-802x1024-802x1024-44.png" type="image/x-icon">
  <meta name="description" content="">
  
  <link rel="stylesheet" href="css?family=Roboto:700,400&subset=cyrillic,latin,greek,vietnamese" tppabs="https://fonts.googleapis.com/css?family=Roboto:700,400&subset=cyrillic,latin,greek,vietnamese">
  <link rel="stylesheet" href="http://bombnet.ru/assets/bootstrap/css/bootstrap.min.css" tppabs="http://bombnet.ru/assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="http://bombnet.ru/assets/animate.css/animate.min.css" tppabs="http://bombnet.ru/assets/animate.css/animate.min.css">
  <link rel="stylesheet" href="http://bombnet.ru/assets/mobirise/css/style.css" tppabs="http://bombnet.ru/assets/mobirise/css/style.css">
  <link rel="stylesheet" href="http://bombnet.ru/assets/mobirise/css/mbr-additional.css" tppabs="http://bombnet.ru/assets/mobirise/css/mbr-additional.css" type="text/css">

  
  
</head>
<body>
<section class="mbr-navbar mbr-navbar--freeze mbr-navbar--absolute mbr-navbar--transparent mbr-navbar--auto-collapse" id="menu-4">
    <div class="mbr-navbar__section mbr-section">
        <div class="mbr-section__container container">
            <div class="mbr-navbar__container">
                <div class="mbr-navbar__column mbr-navbar__column--s mbr-navbar__brand">
                    <span class="mbr-navbar__brand-link mbr-brand mbr-brand--inline">


                    </span>
                </div>
                <div class="mbr-navbar__hamburger mbr-hamburger"><span class="mbr-hamburger__line"></span></div>
                <div class="mbr-navbar__column mbr-navbar__menu">
                    <nav class="mbr-navbar__menu-box mbr-navbar__menu-box--inline-right">
                        <div class="mbr-navbar__column">
                          
                      </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
  <center><h1>Сайт компании для интернета здесь все марки фирмы и учет</h1></center>
<section class="engine"><a rel="external" href="javascript:if(confirm('https://mobirise.com/  \n\nThis file was not retrieved by Teleport Pro, because it is addressed using an unsupported protocol (e.g., gopher).  \n\nDo you want to open it from the server?'))window.location='https://mobirise.com/'" tppabs="https://mobirise.com/">web site maker</a></section><section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size mbr-section--full-height mbr-section--bg-adapted" id="header1-3" style="background-image: url(http://bombnet.ru/assets/images/bombnet-1440x1080-17.jpg);">
    <div class="mbr-box__magnet mbr-box__magnet--sm-padding mbr-box__magnet--center-center mbr-after-navbar">
        
        <div class="mbr-box__container mbr-section__container container">
            <div class="mbr-box mbr-box--stretched"><div class="mbr-box__magnet mbr-box__magnet--center-center">
                <div class="row"><div class=" col-sm-8 col-sm-offset-2">
                    <div class="mbr-hero animated fadeInUp">
                        
                        
                    </div>
                    
                </div></div>
            </div></div>
        </div>
        
    </div>
</section>

<section class="mbr-section mbr-section--relative mbr-section--fixed-size mbr-background" id="content5-5" style="background-image: url(assets/images/28-2394-oboi-gradientnyj-fon-2560x1024-2560x1024-97.jpg);">
    <div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(0, 0, 0);"></div>
    <div class="mbr-section__container container mbr-section__container--first" style="padding-top: 124px;">
        <div class="mbr-header mbr-header--wysiwyg row">
            <div class="col-sm-8 col-sm-offset-2">
	<style type="text/css">

<?php
/*
 * - $LastChangedDate$
 * - $Rev$
 */

// Define default map guessing
switch($skin_color) {
  case "blue":
    $skin_mt_color = '#739fce';
    break;
  case "brown":
    $skin_mt_color = '#c59469';
    break;
  case "green":
    $skin_mt_color = '#66a749';
    break;
  case "grey":
    $skin_mt_color = '#777777';
    break;
  case "pink":
    $skin_mt_color = '#a84989';
    break;
  case "purple":
    $skin_mt_color = '#5349a9';
    break;
  case "red":
    $skin_mt_color = '#b63a3a';
    break;
  case "turquoise":
    $skin_mt_color = '#48a89d';
    break;
  case "yellow":
    $skin_mt_color = '#b4b43a';
    break;
}
?>		
   
	</style>
	<!--[if !IE]>-->

	<!--<![endif]-->
	<meta name="viewport" content="width=320; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />


	<?php if(is_right_to_left($lang)) { ?>
	<style type="text/css">
		<!--
		/* CSS for right to left */
		label {margin-left:0.5em;float:right;text-align:right;}
		#content,#right,.right {float:left;}
		#nav,#left,.left {float:right;}
		-->
	</style>
	<?php } else {} ?>
  <script src="http://bombnet.ru/assets/web/assets/jquery/jquery.min.js" tppabs="http://bombnet.ru/assets/web/assets/jquery/jquery.min.js"></script>
  <script src="http://bombnet.ru/assets/bootstrap/js/bootstrap.min.js" tppabs="http://bombnet.ru/assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="http://bombnet.ru/assets/smooth-scroll/SmoothScroll.js" tppabs="http://bombnet.ru/assets/smooth-scroll/SmoothScroll.js"></script>
  <script src="http://bombnet.ru/assets/mobirise/js/script.js" tppabs="http://bombnet.ru/assets/mobirise/js/script.js"></script>
  