﻿<?php
/* 
	Appointment: Карту
	File: maps.php
	Author: JackerScripts
 
*/
if(!defined('MOZG'))
	die('Hacking attempt!');

if($ajax == 'yes')
	NoAjaxQuery();

if($logged){
	$act = $_GET['act'];
	$id = intval($_GET['id']);
	$user_id = intval($user_info['user_id']);
	
	switch($act){
	
		//################### Страница добавления карту на стену ###################//
		case "mapsbox":
		$row = $db->super_query("SELECT user_country_city_name FROM `".PREFIX."_users` WHERE user_id = '{$id}'");
		
			$tpl->load_template('maps/ajax_maps.tpl');
		
			$user_country_city_name_exp = explode('|', $row['user_country_city_name']);
			//Страна и город
			$tpl->set('{city}', $user_country_city_name_exp[1]);
			$tpl->compile('content');
		AjaxTpl();
		die();
		$tpl->clear();
		$db->free();
		break;
		
		//################### Добавление карту в БД ###################//
		case "send":
			NoAjaxQuery();

			$title = ajax_utf8(textFilter($_POST['title'], false, true));
			
			if(strlen($title) > 0){

					//Отправка карту на стену
					$wall_text = "<div style=\"max-width: 500px;\"><img src=\"http://maps.googleapis.com/maps/api/staticmap?center={$title}&zoom=10&size=500x300&maptype=roadmap&markers=color:blue%7C{$title}&sensor=false&scale=1&visual_refresh=true\" /></div>";
				
					$wall_text = $db->safesql($wall_text);

					//Вставляем саму запись в БД
					$db->query("INSERT INTO `".PREFIX."_wall` SET author_user_id = '{$user_id}', for_user_id = '{$user_id}', text = '{$wall_text}', add_date = '{$server_time}', type = ''");
					$dbid = $db->insert_id();
				
					//Вставляем в ленту новостей
					$db->query("INSERT INTO `".PREFIX."_news` SET ac_user_id = '{$user_id}', action_type = 1, action_text = '{$wall_text}', obj_id = '{$dbid}', action_time = '{$server_time}'");
				
					//Обновляем кол-во записей
					$db->query("UPDATE `".PREFIX."_users` SET user_wall_num = user_wall_num+1 WHERE user_id = '{$user_id}'");
			
			}
			header("Location: /u{$for_user_id}");
			die();
		break;
		
		default:
		
	
	}
	$tpl->clear();
	$db->free();
} else {
	$user_speedbar = $lang['no_infooo'];
	msgbox('', $lang['not_logged'], 'info');
}
?>