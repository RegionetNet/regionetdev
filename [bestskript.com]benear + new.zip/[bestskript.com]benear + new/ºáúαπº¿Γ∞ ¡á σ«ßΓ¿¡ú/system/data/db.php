<?php

define ("DBHOST", "up.test2.ru"); 

define ("DBNAME", "up");

define ("DBUSER", "up");

define ("DBPASS", "axmedaa");  

define ("PREFIX", "vii"); 

define ("COLLATE", "utf8");

$db = new db;

?>