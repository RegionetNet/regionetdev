<?php 

//System Configurations

$config = array (

'home' => "8888888888",

'charset' => "utf-8",

'home_url' => "http://up.test2.ru/",

'temp' => "Default",

'online_time' => "140",

'lang' => "Russian",

'gzip' => "yes",

'gzip_js' => "no",

'offline' => "no",

'offline_msg' => " Сайт будет доступен в ближайшее время. Приносим свои извинения за доставленные не удобства! ",

'bonus_rate' => "1",

'cost_balance' => "1",

'video_mod' => "yes",

'video_mod_comm' => "yes",

'video_mod_add' => "yes",

'video_mod_add_my' => "yes",

'video_mod_search' => "yes",

'audio_mod' => "yes",

'audio_mod_add' => "yes",

'audio_mod_search' => "yes",

'album_mod' => "yes",

'max_albums' => "20",

'max_album_photos' => "500",

'max_photo_size' => "5000",

'photo_format' => "jpg, jpeg, jpe, png, gif",

'albums_drag' => "yes",

'photos_drag' => "yes",

'rate_price' => "5",

'admin_mail' => "8888888",

'mail_metod' => "php",

'smtp_host' => "localhost",

'smtp_port' => "25",

'smtp_user' => "8888888",

'smtp_pass' => "8888888",

'news_mail_1' => "yes",

'news_mail_2' => "yes",

'news_mail_3' => "yes",

'news_mail_4' => "yes",

'news_mail_5' => "yes",

'news_mail_6' => "yes",

'news_mail_7' => "yes",

'news_mail_8' => "yes",

);

?>